df = pd.read_csv(''imdb_top_1000.csv")

from pathlib import Path
Path('data.db').touch()

import sqlite3
conn = sqlite3.connect('data.db')
c = conn.cursor()


print(df.to_string())
c.execute('''users (user_id int, username text)''')
import pandas as pd
 
users = pd.read_csv('imdb_top_1000.csv')

users.to_sql('users', conn, if_exists='append', index = False)